Aesthetic Renovations – Website (Static)

This site is a simple static website so it’s easy to publish from your phone.

STEP 1: Put your photos in the /assets folder and name them EXACTLY:
- p1-before.jpg   p1-after.jpg
- p2-before.jpg   p2-after.jpg
- p3-before.jpg   p3-after.jpg
- p4-before.jpg   p4-after.jpg

STEP 2: Publish on Vercel (phone steps)
A) Create a GitHub repo (on github.com)
B) Upload ALL files from this folder into the repo:
   index.html, styles.css, script.js, assets/*
C) In Vercel: Add New -> Project -> Import Git Repository -> Deploy

Framework preset: Other
Build command: (leave blank)
Output directory: (leave blank)

Contact info already included:
Phone: 337-532-9108
Email: Eddiesalazar90@gmail.com
Facebook: https://facebook.com/AestheticRenovations
Service areas: Houston, Austin, San Antonio, Dallas
